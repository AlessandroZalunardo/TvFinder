const favoritesList = document.getElementById("favoritesList");

let favorites = JSON.parse(localStorage.getItem("favorites")) || [];

if (favorites.length === 0) {
    favoritesList.innerHTML = "<p>No favorite shows yet.</p>";
} else {
    favorites.forEach(show => {
        const div = document.createElement("div");
        div.classList.add("card");

        const imageUrl = show.image ? show.image.medium : "";

        div.innerHTML = `
            ${imageUrl ? `<img src="${imageUrl}" alt="${show.name}">` : "<p>No image available</p>"}
            <h3>${show.name}</h3>
            <p>${show.genres && show.genres.length ? show.genres.join(", ") : "No genres"}</p>
            <p>Rating: ${show.rating && show.rating.average ? show.rating.average : "N/A"}</p>
            <div class="extra" style="display:block;">
                <p><strong>Language:</strong> ${show.language || "N/A"}</p>
                <p><strong>Status:</strong> ${show.status || "N/A"}</p>
                <p><strong>Premiered:</strong> ${show.premiered || "N/A"}</p>
                <p>${show.summary ? show.summary.replace(/<[^>]+>/g, "") : "No summary available"}</p>
            </div>
        `;

        favoritesList.appendChild(div);
    });
}
function clearFavorites() {
    localStorage.removeItem("favorites");
    location.reload(); // refresh page
}