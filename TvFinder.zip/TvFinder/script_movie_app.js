const searchBtn = document.getElementById("searchBtn");
const searchInput = document.getElementById("searchInput");
const results = document.getElementById("results");

searchBtn.addEventListener("click", searchShows);

searchInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        searchShows();
    }
});

async function searchShows() {
    const query = searchInput.value.trim();

    if (!query) {
        results.innerHTML = "<p>Please enter a show name.</p>";
        return;
    }

    results.innerHTML = "<p>Loading...</p>";

    try {
        const res = await fetch(`https://api.tvmaze.com/search/shows?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        showResults(data);
    } catch (error) {
        results.innerHTML = "<p>Error loading shows.</p>";
        console.error(error);
    }
}

function showResults(data) {
    results.innerHTML = "";

    if (data.length === 0) {
        results.innerHTML = "<p>No shows found.</p>";
        return;
    }

    data.forEach(item => {
        const show = item.show;

        const div = document.createElement("div");
        div.classList.add("card");

        const imageUrl = show.image ? show.image.medium : "";

        div.innerHTML = `
            ${imageUrl ? `<img src="${imageUrl}" alt="${show.name}">` : "<p>No image available</p>"}
            <h3>${show.name}</h3>
            <p>${show.genres.join(", ") || "No genres"}</p>
            <p>Rating: ${show.rating.average || "N/A"}</p>
            <button class="add-btn">Add to Favorites</button>
            <div class="extra" style="display:none;"></div>
        `;

        div.addEventListener("click", () => showMore(show, div));

        div.querySelector(".add-btn").addEventListener("click", function (event) {
            event.stopPropagation();
            addFav(show);
        });

        results.appendChild(div);
    });
}

function showMore(show, card) {
    const extraDiv = card.querySelector(".extra");

    if (extraDiv.style.display === "block") {
        extraDiv.style.display = "none";
        return;
    }

    extraDiv.style.display = "block";

    extraDiv.innerHTML = `
        <p><strong>Language:</strong> ${show.language || "N/A"}</p>
        <p><strong>Status:</strong> ${show.status || "N/A"}</p>
        <p><strong>Premiered:</strong> ${show.premiered || "N/A"}</p>
        <p>${show.summary ? show.summary.replace(/<[^>]+>/g, "") : "No summary available"}</p>
    `;
}

function addFav(show) {
    let favorites = JSON.parse(localStorage.getItem("favorites")) || [];

    const alreadySaved = favorites.some(fav => fav.id === show.id);

    if (!alreadySaved) {
        favorites.push(show);
        localStorage.setItem("favorites", JSON.stringify(favorites));
        alert("Added to favorites!");
    }
}
const recommendedDiv = document.getElementById("recommended");

// runs when page loads
loadRecommended();

async function loadRecommended() {
    try {
        const res = await fetch("https://api.tvmaze.com/shows");
        const data = await res.json();

        showRecommended(data.slice(0, 200));

    } catch (err) {
        recommendedDiv.innerHTML = "<p>Error loading recommendations</p>";
    }
}

function showRecommended(shows) {
    recommendedDiv.innerHTML = "";

    shows.forEach(show => {
        const div = document.createElement("div");
        div.classList.add("card");

        const imageUrl = show.image ? show.image.medium : "";

        div.innerHTML = `
            ${imageUrl ? `<img src="${imageUrl}" alt="${show.name}">` : "<p>No image available</p>"}
            <h3>${show.name}</h3>
            <p>Rating: ${show.rating.average || "N/A"}</p>
            <button class="add-btn">Add</button>
            <div class="extra" style="display:none;"></div>
        `;

        div.addEventListener("click", () => showMore(show, div));

        div.querySelector(".add-btn").addEventListener("click", function (event) {
            event.stopPropagation();
            addFav(show);
        });

        recommendedDiv.appendChild(div);
    });
}